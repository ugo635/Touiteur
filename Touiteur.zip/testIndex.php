<?php

require_once __DIR__ . '/vendor/autoload.php';

use iutnc\touiteur\bdd\TouiteurRepository;
use iutnc\touiteur\dispatch\Dispatcher;
use iutnc\touiteur\render\RendererFactory;
use iutnc\touiteur\touite\Touite;
use iutnc\touiteur\users\User;

session_start();
TouiteurRepository::setConfig(__DIR__ . '/config/config.db.ini');

$dispatcher = new Dispatcher();
$dispatcher->run();

/*$user = new User("ugo635");
$touite = new Touite("Voici 3 raisons pour lesquelles #php psmr.<br>
1. Deja la syntaxe est super moche<br>
2. Java existe donc forcément que php psmr<br>
3. Jsp", $user);

TouiteurRepository::getInstance()->saveTouite($touite);
echo RendererFactory::getRenderer($touite)->render();*/